<?php 
    echo $_POST["id"];  // 顯示使用者輸入的帳號
    echo "<br>"; //換行
    echo $_POST["pwd"]; // 顯示使用者輸入的密碼
?>
